import json
import bibtexparser
import itertools
import re

from latexenc import unicode_to_latex, unicode_to_crappy_latex1, unicode_to_crappy_latex2
from consistency_check import ConsistencyCheck


class RenderSyscopBibtex:
    """ Class to render the syscop bibtex library for our web page publications list.
        Use this class to parse bibtex to Json for all entries with the KEYWORD.
    """

    KEYWORDS = ['syscop-public',
                'syscop-public-no-pdf']  # Process syscop.bib entries with occurrence of one of this keywords.
    EXCLUDE_KEYS = ['ENTRYTYPE',
                    'ID',
                    'owner',
                    'timestamp',
                    'file',
                    'note',
                    'abstract']  # Keys to be excluded from the generated bibtex code.

    def __init__(self):
        # the relevant entries for the webpage
        self.web_entries = []

        # Load the bibtex file and generate the database
        with open('../syscop.bib', encoding="utf-8") as bibtex_file:
            self.bib_database = bibtexparser.load(bibtex_file)

    def filter_relevant(self):
        """ Push relevant entries into web_entries. """
        for entry in self.bib_database.entries:
            # Take all entries with the occurrence of the keyword "syscop-public"
            if 'keywords' in entry and any(keyword in entry['keywords'] for keyword in self.KEYWORDS):
                entry = self.process_entry(entry)
                self.web_entries.append(entry)

    def process_entry(self, entry):
        """ Process bibtex entry for the needs of the web page.
        We want to have a dict like:

        {
            "keywords": "...",
            "subtitle": "...",
            "authors": "...",
            "title": "...",
            "year": "...",
            "file": "...",
            "bibtex": [
                "one",
                "entry",
                "per",
                "line"
                ],
            "ordering": "int"
        }

        Args:
            entry (dict):
        """
        result = dict()
        raw_entry = entry.copy()  # Keep a raw copy for generating the bibtex code.
        entry = self.convert_to_unicode(entry)
        self.rm_parentheses(entry, 'title')
        self.rm_parentheses(entry, 'author')
        self.name(entry, 'author')
        self.name(entry, 'editor')

        if 'keywords' in entry:
            result['keywords'] = entry['keywords']

        if 'journal' in entry:
            result['subtitle'] = entry['journal']
        elif 'booktitle' in entry:
            result['subtitle'] = entry['booktitle']
        elif 'chapter' in entry:
            result['subtitle'] = entry['chapter']
        elif 'institution' in entry:
            result['subtitle'] = entry['institution']
        elif 'publisher' in entry:
            result['subtitle'] = entry['publisher']
        elif 'school' in entry:
            result['subtitle'] = entry['school']
        else:
            result['subtitle'] = ''

        if 'author' in entry:
            result['authors'] = ', '.join(entry['author'])
        elif 'editor' in entry:
            result['authors'] = ', '.join(entry['editor'])
        else:
            result['authors'] = ''

        if 'title' in entry:
            result['title'] = entry['title']
        else:
            result['title'] = ''

        if 'year' in entry:
            result['year'] = entry['year']
        else:
            result['year'] = ''

        # Don't publish PDF if it is tagged 'syscop-public-no-pdf'.
        if 'file' in entry and 'syscop-public-no-pdf' not in entry['keywords']:
            result['file'] = entry['file']
        else:
            result['file'] = ''

        # parse the type of the entry. Goal is to append e.g. (Masters thesis) to the public table
        if raw_entry['ENTRYTYPE'] in ['mastersthesis', 'phdthesis']:
            if 'type' in entry:
                result['authors_pre'] = entry['type']
            elif raw_entry['ENTRYTYPE'] == 'mastersthesis':
                result['authors_pre'] = 'Masters thesis'
            elif raw_entry['ENTRYTYPE'] == 'phdthesis':
                result['authors_pre'] = 'PhD thesis'
        else:
            result['authors_pre'] = ''

        # Generate a list for the bibtex code for one entry.
        # This list has to be one element for each line of the entry.
        # This is because json not supporting newlines.
        # To render this back to the bibtex entry we use javascript in the frontend.

        # First generate the Header
        bibtex_code = ['@' + raw_entry['ENTRYTYPE'] + '{' + raw_entry['ID'] + ',']

        # Add all the attributes
        for key, value in raw_entry.items():
            if key not in self.EXCLUDE_KEYS:
                bibtex_code.append('\t' + key + ' = {' + value + '},')
        bibtex_code.append('}')

        result['bibtex'] = bibtex_code

        # Since we order by year, we cann add secondary ordering information to it to achieve nested orderings.
        if 'year' in entry and entry['ENTRYTYPE'] == 'article':
            result['ordering'] = (entry['year'] + '1')
        elif 'year' in entry:
            result['ordering'] = (entry['year'] + '0')
        else:
            result['ordering'] = ''

        return result

    def write_json(self):
        """ Generate json file out of the entries """
        with open('syscopbib.json', 'w') as file:
            json.dump({'data': self.web_entries}, file)

    def write_pdf_files_index(self):
        """ Generate an Index file for all PDF entries.
        :return: Null
        """
        with open('pdf_index.txt', 'w') as file:
            for entry in self.web_entries:
                if 'file' in entry and entry['file']:  # Add filename if we have one
                    parts = re.split('/', entry['file'])[-1]
                    filename = re.split(':PDF', parts)[0]
                    file.write(filename + '\n')

    def name(self, record, entry):
        """
        Split a field of names into a list of "F. Name" where S is the first char of the Firstname.

        :param record: the record.
        :param entry: the record key.
        :type record: dict
        :returns: dict -- the modified record.

        """
        if entry in record:
            if record[entry]:
                record[entry] = self.getnames([i.strip() for i in record[entry].replace('\n', ' ').split(" and ")])
            else:
                del record[entry]
        return record

    def getnames(self, names):
        """Make people names as firstnames, surname
        or initials, surname. Should eventually combine up the two.

        :param names: a list of names
        :type names: list
        :returns: list -- Correctly formated names
        """
        surname_prefixes = ['ben', 'van', 'der', 'de', 'la', 'le']
        tidynames = []
        for namestring in names:
            namestring = namestring.strip()
            if len(namestring) < 1:
                continue
            if ',' in namestring:
                namesplit = namestring.split(',', 1)
                last = namesplit[0].strip()
                firsts = [i.strip() for i in namesplit[1].split()]
            else:
                namesplit = namestring.split()
                last = namesplit.pop()
                firsts = [i.replace('.', '. ').strip() for i in namesplit]
            for i, first in enumerate(firsts):  # Abbreviate Surnames
                if len(first) > 2 and first not in surname_prefixes:
                    firsts[i] = first[0:1] + '.'
            if last in ['jnr', 'jr', 'junior']:
                last = firsts.pop()
            for item in firsts:
                if item in surname_prefixes:
                    last = firsts.pop() + ' ' + last
            tidynames.append((' '.join(firsts) + " " + last).strip())
        return tidynames

    def convert_to_unicode(self, record):
        """
        Convert accent from latex to unicode style.

        :param record: the record.
        :type record: dict
        :returns: dict -- the modified record.
        """
        for val in record:
            if '\\' in record[val] or '{' in record[val]:
                for k, v in itertools.chain(unicode_to_crappy_latex1, unicode_to_latex):
                    if v in record[val]:
                        record[val] = record[val].replace(v, k)

            # If there is still very crappy items
            if '\\' in record[val]:
                for k, v in unicode_to_crappy_latex2:
                    if v in record[val]:
                        parts = record[val].split(str(v))
                        for key, record[val] in enumerate(parts):
                            if key+1 < len(parts) and len(parts[key+1]) > 0:
                                # Change order to display accents
                                parts[key] = parts[key] + parts[key+1][0]
                                parts[key+1] = parts[key+1][1:]
                        record[val] = k.join(parts)
        return record

    def rm_parentheses(self, record, key):
        """
        Remove '{' and '}' parentheses in the entry provided by key.

        :param record: the record.
        :param key: the key for the value to be affected.
        :type record: dict
        :returns: dict -- the modified record.

        """
        if key in record:
            if record[key]:
                record[key] = record[key].replace('{', '')
                record[key] = record[key].replace('}', '')
        return record

if __name__ == '__main__':
    bib = RenderSyscopBibtex()
    print('Filter relevant entries...', end='')
    bib.filter_relevant()
    print(' done.')
    print('writing json file...', end='')
    bib.write_json()
    print(' done.')
    print('Process consistency check.')
    cc = ConsistencyCheck()
    cc.run_consistency_checks()
    print('Generate pdf file index.')
    bib.write_pdf_files_index()
