# What is happening here?
The CI of this repository is running `render_syscop_bibtex.py`
    
Which produces two outputs `syscopbib.json` containing all the entries for the 
database used in the syscop.de publications list.
The other file is `pdf_index.txt` containing all PDF filenames to be downloadable in the associated entry.

CI is then uploading this files to `ftp://static.syscop.de/syscopbibtex/` logging in with the
password saved on the CI variables of this "gitlab project".

On the webserver, `/var/www/crons/sync_publication_pdfs.py` is triggered every 10 minutes by a cron rule (defined in `/var/spool/cron/crontabs/root`) 
to syncronize the actual PDF files from Owncloud to the cdn.syscop.de static webserver (by symlink) 
if they should be downloadable to the public and if they exist in Owncloud.

