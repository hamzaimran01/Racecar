#!/usr/bin/env python3.5
import pprint
import urllib.request
import re

from os.path import isfile, islink, join
from os import listdir, remove, symlink

""" Goal: sync bibtex file entries with cdn.syscop.de/publications
    * We generate a .txt file with all the filenames of the pdf's out of the bibtex file
    * We symlink the files to the root directory of cdn.syscop.de/publications
    * We sync [existing files] <-> [filelist] <-> [symlinks]
    * We contab this.
"""

FILENAMES_URL = 'http://static.syscop.de/syscopbibtex/pdf_index.txt'
FILES_SOURCE = '/files/owncloud/data/SYSCOP/files/syscop_bib_pdf/'
FILES_DEST = '/var/www/cdn/publications/'

# Fetch the pdf index file.
response = urllib.request.urlopen(FILENAMES_URL)
data = response.read().decode('utf-8')
filenames = re.split('\n', data)

# ged rid of whitespace.
filenames = [l for l in (line.strip() for line in filenames) if l]

# fetch all existing files.
existing_files = [filename for filename in filenames if isfile(FILES_SOURCE + filename)]

# fetch all existing links.
existing_links = [f for f in listdir(FILES_DEST) if islink(join(FILES_DEST, f))]

# Delete all existing symlinks not in the filenames list.
for link in existing_links:
    if link not in existing_files:
        remove(join(FILES_DEST, link))

# Add all symlinks missing.
for file in existing_files:
    if file not in existing_links:
        symlink(join(FILES_SOURCE, file), join(FILES_DEST, file))
