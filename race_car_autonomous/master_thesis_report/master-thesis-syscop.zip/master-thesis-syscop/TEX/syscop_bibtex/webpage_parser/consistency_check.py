import pprint
import bibtexparser
import random
import string
from email.utils import formatdate
from smtplib import *


class ConsistencyCheck:
    """ Class to run some consistency checks against our bibtex file.

     To extend this with your own checks, create a new method like check_year and register it in the for loop of the
     run_consistency_checks method. If you do local testings please set SENT_MAIL to False.

     If you also want to get notified about errors, add you mail adress into the ERROR_RECIPIENTS list.

    """
    ERROR_RECIPIENTS = ['roths@informatik.uni-freiburg.de']
    SENT_MAIL = False  # Set this to None or False to deactivate sending error emails.

    def __init__(self):
        self.error_msg = dict()  # collect all errors in here. One entry per ID

        # Load the bibtex file and generate the database
        with open('../syscop.bib', encoding="utf-8") as bibtex_file:
            bibtex_str = bibtex_file.read()

        self.bib_database = bibtexparser.loads(bibtex_str)

    def check_year(self, entry):
        """ Example method to check the bibtex entry for correct use of the year attribute.

        We check if we have the 'year', if its a int, if it is in the range [1000, 2500].
        If not, add an error to the self.error_msg dictionary with the entry ID as key

        :param entry: dict
        """
        error = ''

        try:
            year = int(entry['year'])
            if year not in range(1000, 2500):
                error = 'Year (' + year + ') not in range [1000, 2500)'
        except ValueError as e:
            error = 'Year is not in the right format: ' + str(e)
        except KeyError:
            error = 'Year is missing.'
        except Exception as e:
            error = 'Unexpected error for Year: ' + str(e)

        # Add the error to if we have one.
        if error:
            self.add_error(entry, error)

    def run_consistency_checks(self):
        """ Run all the consistency checks against the data. """
        for entry in self.bib_database.entries:
            # Here we register all the methods one entry should be checked against.
            self.check_year(entry)

        if self.error_msg and self.SENT_MAIL:
            self.sent_mail()

    def add_error(self, entry, error):
        """ Add error to the entry error list.

        :param entry: dict
        :param error: string
        """
        if entry['ID'] not in self.error_msg:
            self.error_msg[entry['ID']] = list()
        self.error_msg[entry['ID']].append(error)

    def sent_mail(self):
        """ Sent the errors to the ERROR_RECIPIENTS. """

        user = 'bibtex@syscop.de'
        pwd = 'VyKNDVUWTo4my5vZz8T4'

        pp = pprint.PrettyPrinter(indent=4, width=120)
        error = pp.pformat(self.error_msg)
        message_id = ''.join(random.choice(string.hexdigits) for _ in range(32))

        print('Sending error notification email...')

        with SMTP('mail.syscop.de', 587) as smtpserver:
            smtpserver.ehlo()
            smtpserver.starttls()
            smtpserver.ehlo()
            smtpserver.login(user, pwd)
            for to in self.ERROR_RECIPIENTS:
                header = 'To:' + to + '\n' + 'From: ' + user + '\n' + 'Subject:Syscop BibTex: Error report \n'
                header += 'Date:' + formatdate(localtime=True) + '\n'
                header += 'Message-ID:<' + message_id + '@syscop.de>\n'
                print(header)
                msg = header + '\n Consistency check for syscop_bibtex spotted some errors. \n Namely: \n ' + error + ' \n\n'
                smtpserver.sendmail(user, to, msg)
            print('Done!')
            smtpserver.close()


if __name__ == '__main__':
    bib = ConsistencyCheck()
    bib.run_consistency_checks()
