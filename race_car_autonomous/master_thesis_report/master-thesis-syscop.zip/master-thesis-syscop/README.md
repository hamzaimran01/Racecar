This repository is meant to give a starting point for students writing their thesis at the syscop chair.

# Get started:
- clone this repository
- clone submodules, running `git submodule update --recursive --init`
- set up a fork of this repo and share it with your supervisor