Beamer template of SYSCOP group.

Feel free to contribute to it.

In folder 'users', you may want to upload your personal style sheet to be loaded on top of the presentation style. In that way, you can keep your personal preferences up to date and share them with other members of the group.