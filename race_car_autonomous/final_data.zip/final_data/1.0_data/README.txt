
-> record data again for a whole lap as tjhe first part is missing due to inaccurate results
